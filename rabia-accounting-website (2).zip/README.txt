# Rabia Tayyab Accounting Website

Open `index.html` in a browser to preview the website.

Before publishing:
1. Replace `YOUR-EMAIL@example.com` in index.html with your real business email.
2. Optionally add a WhatsApp/contact link.
3. Add your final business name/logo if you want one.
4. Publish the folder using your preferred web host.

The site is intentionally written for a professional first presentation to FlowSync and potential UK small-business clients.
